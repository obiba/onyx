using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows.Forms;
using EMR.PlugIn.Basic;
using ndd.EMR.SharedConst;

namespace EMR.PlugIn.TestBench
{
  /// <summary>
  /// This plug in is for testing purpose only. </summary>
  public class TestBenchPlugIn : EMR.PlugIn.Basic.EmrPlugIn
  {

    #region - PlugIn Information - static -

    /// <summary>
    /// Name shown in the EMR selection drop down list.</summary>
    /// <remarks>required</remarks>
    public static new string Name
    {
      get { return Properties.Resources.PlugInName; }
    }
    #endregion

    #region - PlugIn Configuration - static -
    /// <summary>
    /// Control containing GUI elements to configure plugIn settings.</summary>
    /// <remarks>required when PlugIn is configurable</remarks>
    public static new Control ConfigurationControl
    {
      //not supported in this example
      get { return new UserControlEmrConfig(); }
      //get { return null; }
    }


    #endregion

    #region - Constructor, Initialization, Close -

    /// <summary>
    /// Constructor, parameterless</summary>
    ///<remarks>required: parametereless</remarks>
    public TestBenchPlugIn()
    {
    }

    protected EMRTestForm _benchForm;
    /// <summary>
    /// Initialization and starting EMR Module</summary>
    /// <param name="configValues">saved configuration values, <see cref="UserControlEmrConfig"/></param>
    /// <returns>true if successfull</returns>
    /// <remarks>required</remarks>
    public override bool Initialize(Dictionary<string, string> configValues)
    {
      //load saved configuration values
      base.Initialize(configValues);

      _benchForm = new EMRTestForm(this);
      _benchForm.Show();

      return true;
    }

    /// <summary>
    /// Stops the EMR module. You could call dispose() in case you have resources to free.</summary>
    /// <remarks>required</remarks>
    public override void Close()
    {
      if (_benchForm != null)
        _benchForm.Close();

      base.Close();

      _benchForm = null;
    }


    protected override void LoadingConfigValues(Dictionary<string, string> configValues)
    {
      base.LoadingConfigValues(configValues);
    }


    /// <summary>
    /// return plugin configuration values, which are relevant for EasyWarePro</summary>
    /// <param name="xmlWriter"></param>
    protected override void WriteConfiguration(System.Xml.XmlTextWriter xmlWriter)
    {
      base.WriteConfiguration(xmlWriter);

      //the parameters below are not configurable through the EasyWarePro configuration (not in UserCtrlEmrCfg)
      WriteParameter(xmlWriter, Commands.Configuration.AttachReport, Properties.Settings.Default.Config_AttachPDF.ToString(CultureInfo.InvariantCulture));
      WriteParameter(xmlWriter, Commands.Configuration.AttachmentFileName, Properties.Settings.Default.AttachmentFileNamePart1 + Properties.Settings.Default.AttachmentFileNamePart2 + Properties.Settings.Default.AttachmentFileNamePart3);
      WriteParameter(xmlWriter, Commands.Configuration.AttachmentFormat, Properties.Settings.Default.AttachmentFormat);
    }

    protected override List<string> GetSupportedFeatures()
    {
      List<string> features = base.GetSupportedFeatures();

      if (Properties.Settings.Default.Supported_SearchPatients)
        features.Add(Commands.SupportedFeatures.SearchPatients);

      if (Properties.Settings.Default.Supported_Worklist)
        features.Add(Commands.SupportedFeatures.Worklist);

      return features;

    }

    #endregion

    #region - handling receiving data -
    public override string ReceiveXmlMessage(string strMessage)
    {
      //log
      if (OnLogMessage != null)
        OnLogMessage("Received data from EasyWarePro:" + System.Environment.NewLine + strMessage);

      return base.ReceiveXmlMessage(strMessage);
    }
    #endregion

    #region - returning data -
    //e.g. Worklist, CurveData, Attachment_Type, Attachment_Path
    protected string ReturnWorklist(Dictionary<string, string> parameters)
    {
      using (System.Xml.XmlWriter xmlWriter = new System.Xml.XmlTextWriter(XmlExchangeFile, Encoding.UTF8))
      {
        try
        {
          xmlWriter.WriteStartDocument();
          xmlWriter.WriteStartElement("ndd");
          xmlWriter.WriteStartElement("Command");
          xmlWriter.WriteAttributeString("Type", "Worklist");
          //xmlWriter.WriteStartElement("Parameter");
          //xmlWriter.WriteAttributeString("Name", "WorklistPatient");
          //xmlWriter.WriteValue("SearchPatients");
          //xmlWriter.WriteEndElement();//parameter
          xmlWriter.WriteEndElement();//command
          xmlWriter.WriteStartElement("Patients");
          xmlWriter.WriteStartElement("Patient");
          xmlWriter.WriteEndElement();//Patient
          xmlWriter.WriteEndElement();//Patients
          xmlWriter.WriteEndElement();
          xmlWriter.WriteEndDocument();
          //                xmlWriter.WriteString(@"
          //<ndd>
          //<command>Test xml data</command><Patients>
          //    <Patient ID=""PSM-11213"">
          //      <LastName>Smith</LastName>
          //      <FirstName>Peter</FirstName></Patient>
          //</Patients>
          //</ndd>");
          xmlWriter.Flush();
          xmlWriter.Close();
          return XmlExchangeFile;
        }
        finally
        {
          xmlWriter.Close();
        }
      }
    }

    protected override string ReturnSearchPatientResult(Dictionary<string, string> parameters)
    {
      using (System.Xml.XmlWriter xmlWriter = new System.Xml.XmlTextWriter(XmlExchangeFile, Encoding.UTF8))
      {
        try
        {
          xmlWriter.WriteStartDocument();
          xmlWriter.WriteStartElement("ndd");
          xmlWriter.WriteStartElement("Command");
          xmlWriter.WriteAttributeString("Type", Commands.SearchPatientsResult.Command);
          xmlWriter.WriteEndElement();//command
          xmlWriter.WriteStartElement("Patients");

          _benchForm.AddGuiPatient(xmlWriter);
          _benchForm.AddGuiPatient(xmlWriter);
          _benchForm.AddGuiPatient(xmlWriter);

          xmlWriter.WriteEndElement();//Patients
          xmlWriter.WriteEndElement();
          xmlWriter.WriteEndDocument();
          xmlWriter.Flush();
          xmlWriter.Close();
          return XmlExchangeFile;
        }
        finally
        {
          xmlWriter.Close();
        }
      }
    }
    #endregion

    #region - Connection for the Test Bench Form -
    public delegate void OnReceivingMessageDelegate(string strMessage);
    public OnReceivingMessageDelegate OnLogMessage;
    //public delegate string OnReceivingCommandDelegate(Dictionary<string, string> parameterList);
    //public OnReceivingCommandDelegate OnCommandReceive;

    /// <summary>
    /// Log messages send to EasyWarePro</summary>
    public override string SendMessage(string strMessage)
    {
      //log
      if (OnLogMessage != null)
        OnLogMessage("Sent data to EasyWarePro:" + System.Environment.NewLine + strMessage);

      //send data
      string result = base.SendMessage(strMessage);

      //log
      if (OnLogMessage != null)
        OnLogMessage("Received data from EasyWarePro:" + System.Environment.NewLine + result);
      return result;
    }
  }
    #endregion


}

