namespace EMR.PlugInTester
{
    partial class TestForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
          System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TestForm));
          this.buttonInit = new System.Windows.Forms.Button();
          this.buttonGetEmr = new System.Windows.Forms.Button();
          this.comboBoxAvailableEmr = new System.Windows.Forms.ComboBox();
          this.buttonSendData = new System.Windows.Forms.Button();
          this.richTextBoxReceivedMessages = new System.Windows.Forms.RichTextBox();
          this.panelCfgHolder = new System.Windows.Forms.Panel();
          this.buttonShowCfg = new System.Windows.Forms.Button();
          this.buttonSaveCfg = new System.Windows.Forms.Button();
          this.buttonSendFile = new System.Windows.Forms.Button();
          this.buttonGetFeatures = new System.Windows.Forms.Button();
          this.panel1 = new System.Windows.Forms.Panel();
          this.tabControlLoadedPlugin = new System.Windows.Forms.TabControl();
          this.tabPageCommands = new System.Windows.Forms.TabPage();
          this.buttonGetConfiguration = new System.Windows.Forms.Button();
          this.tabPageConfiguration = new System.Windows.Forms.TabPage();
          this.panel1.SuspendLayout();
          this.tabControlLoadedPlugin.SuspendLayout();
          this.tabPageCommands.SuspendLayout();
          this.tabPageConfiguration.SuspendLayout();
          this.SuspendLayout();
          // 
          // buttonInit
          // 
          resources.ApplyResources(this.buttonInit, "buttonInit");
          this.buttonInit.Name = "buttonInit";
          this.buttonInit.UseVisualStyleBackColor = true;
          this.buttonInit.Click += new System.EventHandler(this.buttonInit_Click);
          // 
          // buttonGetEmr
          // 
          resources.ApplyResources(this.buttonGetEmr, "buttonGetEmr");
          this.buttonGetEmr.Name = "buttonGetEmr";
          this.buttonGetEmr.UseVisualStyleBackColor = true;
          this.buttonGetEmr.Click += new System.EventHandler(this.buttonGetEmr_Click);
          // 
          // comboBoxAvailableEmr
          // 
          this.comboBoxAvailableEmr.FormattingEnabled = true;
          resources.ApplyResources(this.comboBoxAvailableEmr, "comboBoxAvailableEmr");
          this.comboBoxAvailableEmr.Name = "comboBoxAvailableEmr";
          // 
          // buttonSendData
          // 
          resources.ApplyResources(this.buttonSendData, "buttonSendData");
          this.buttonSendData.Name = "buttonSendData";
          this.buttonSendData.UseVisualStyleBackColor = true;
          this.buttonSendData.Click += new System.EventHandler(this.buttonSendData_Click);
          // 
          // richTextBoxReceivedMessages
          // 
          resources.ApplyResources(this.richTextBoxReceivedMessages, "richTextBoxReceivedMessages");
          this.richTextBoxReceivedMessages.Name = "richTextBoxReceivedMessages";
          // 
          // panelCfgHolder
          // 
          resources.ApplyResources(this.panelCfgHolder, "panelCfgHolder");
          this.panelCfgHolder.Name = "panelCfgHolder";
          // 
          // buttonShowCfg
          // 
          resources.ApplyResources(this.buttonShowCfg, "buttonShowCfg");
          this.buttonShowCfg.Name = "buttonShowCfg";
          this.buttonShowCfg.UseVisualStyleBackColor = true;
          this.buttonShowCfg.Click += new System.EventHandler(this.buttonShowCfg_Click);
          // 
          // buttonSaveCfg
          // 
          resources.ApplyResources(this.buttonSaveCfg, "buttonSaveCfg");
          this.buttonSaveCfg.Name = "buttonSaveCfg";
          this.buttonSaveCfg.UseVisualStyleBackColor = true;
          this.buttonSaveCfg.Click += new System.EventHandler(this.buttonSaveCfg_Click);
          // 
          // buttonSendFile
          // 
          resources.ApplyResources(this.buttonSendFile, "buttonSendFile");
          this.buttonSendFile.Name = "buttonSendFile";
          this.buttonSendFile.UseVisualStyleBackColor = true;
          this.buttonSendFile.Click += new System.EventHandler(this.buttonSendFile_Click);
          // 
          // buttonGetFeatures
          // 
          resources.ApplyResources(this.buttonGetFeatures, "buttonGetFeatures");
          this.buttonGetFeatures.Name = "buttonGetFeatures";
          this.buttonGetFeatures.UseVisualStyleBackColor = true;
          this.buttonGetFeatures.Click += new System.EventHandler(this.buttonGetFeatures_Click);
          // 
          // panel1
          // 
          this.panel1.Controls.Add(this.comboBoxAvailableEmr);
          this.panel1.Controls.Add(this.buttonGetEmr);
          resources.ApplyResources(this.panel1, "panel1");
          this.panel1.Name = "panel1";
          // 
          // tabControlLoadedPlugin
          // 
          this.tabControlLoadedPlugin.Controls.Add(this.tabPageCommands);
          this.tabControlLoadedPlugin.Controls.Add(this.tabPageConfiguration);
          resources.ApplyResources(this.tabControlLoadedPlugin, "tabControlLoadedPlugin");
          this.tabControlLoadedPlugin.Name = "tabControlLoadedPlugin";
          this.tabControlLoadedPlugin.SelectedIndex = 0;
          // 
          // tabPageCommands
          // 
          this.tabPageCommands.Controls.Add(this.richTextBoxReceivedMessages);
          this.tabPageCommands.Controls.Add(this.buttonInit);
          this.tabPageCommands.Controls.Add(this.buttonSendFile);
          this.tabPageCommands.Controls.Add(this.buttonSendData);
          this.tabPageCommands.Controls.Add(this.buttonGetConfiguration);
          this.tabPageCommands.Controls.Add(this.buttonGetFeatures);
          resources.ApplyResources(this.tabPageCommands, "tabPageCommands");
          this.tabPageCommands.Name = "tabPageCommands";
          this.tabPageCommands.UseVisualStyleBackColor = true;
          // 
          // buttonGetConfiguration
          // 
          resources.ApplyResources(this.buttonGetConfiguration, "buttonGetConfiguration");
          this.buttonGetConfiguration.Name = "buttonGetConfiguration";
          this.buttonGetConfiguration.UseVisualStyleBackColor = true;
          this.buttonGetConfiguration.Click += new System.EventHandler(this.buttonGetConfiguration_Click);
          // 
          // tabPageConfiguration
          // 
          this.tabPageConfiguration.Controls.Add(this.panelCfgHolder);
          this.tabPageConfiguration.Controls.Add(this.buttonShowCfg);
          this.tabPageConfiguration.Controls.Add(this.buttonSaveCfg);
          resources.ApplyResources(this.tabPageConfiguration, "tabPageConfiguration");
          this.tabPageConfiguration.Name = "tabPageConfiguration";
          this.tabPageConfiguration.UseVisualStyleBackColor = true;
          // 
          // Form1
          // 
          resources.ApplyResources(this, "$this");
          this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
          this.Controls.Add(this.tabControlLoadedPlugin);
          this.Controls.Add(this.panel1);
          this.Name = "Form1";
          this.panel1.ResumeLayout(false);
          this.tabControlLoadedPlugin.ResumeLayout(false);
          this.tabPageCommands.ResumeLayout(false);
          this.tabPageConfiguration.ResumeLayout(false);
          this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonInit;
        private System.Windows.Forms.Button buttonGetEmr;
        private System.Windows.Forms.ComboBox comboBoxAvailableEmr;
        private System.Windows.Forms.Button buttonSendData;
        private System.Windows.Forms.RichTextBox richTextBoxReceivedMessages;
        private System.Windows.Forms.Panel panelCfgHolder;
        private System.Windows.Forms.Button buttonShowCfg;
        private System.Windows.Forms.Button buttonSaveCfg;
      private System.Windows.Forms.Button buttonSendFile;
      private System.Windows.Forms.Button buttonGetFeatures;
      private System.Windows.Forms.Panel panel1;
      private System.Windows.Forms.TabControl tabControlLoadedPlugin;
      private System.Windows.Forms.TabPage tabPageCommands;
      private System.Windows.Forms.TabPage tabPageConfiguration;
      private System.Windows.Forms.Button buttonGetConfiguration;
    }
}

