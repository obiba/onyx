using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Globalization;
using ndd.EMR.SharedConst;
using EMR.PlugIn.Basic;

namespace EMR.PlugIn.TestBench
{
  public partial class EMRTestForm : Form
  {
    TestBenchPlugIn _emrPlugIn;

    public EMRTestForm(TestBenchPlugIn emrPlugIn)
    {
      InitializeComponent();

      _emrPlugIn = emrPlugIn;
      _emrPlugIn.OnLogMessage = ReceivingMessage;
    }

    delegate void ReceivingMessageDelegate(string strMessage);
    private void ReceivingMessage(string strMessage)
    {
      if (this.InvokeRequired)
      {
        Invoke(new ReceivingMessageDelegate(ReceivingMessage), new object[] { strMessage });
        return;
      }

      richTextBoxReceivedMessages.Text = DateTime.Now.ToShortTimeString() + " " + strMessage + Environment.NewLine + richTextBoxReceivedMessages.Text;
    }

 

    private void EMRTestForm_FormClosing(object sender, FormClosingEventArgs e)
    {
      Properties.Settings.Default.Save();
    }

    private void buttonAddPatient_Click(object sender, EventArgs e)
    {
      string strCommand = ndd.EMR.SharedConst.Commands.SyncPatient.Command;
      StringBuilder sb = new System.Text.StringBuilder();

      using (System.Xml.XmlTextWriter xmlWriter = new System.Xml.XmlTextWriter(new System.IO.StringWriter(sb, CultureInfo.InvariantCulture)))
      {
        xmlWriter.WriteStartDocument();
        xmlWriter.WriteStartElement("ndd");
        AddCommand(strCommand, xmlWriter);

        xmlWriter.WriteStartElement("Patients");
        AddGuiPatient(xmlWriter);
        xmlWriter.WriteEndElement();//Patients
        xmlWriter.WriteEndElement();
        xmlWriter.WriteEndDocument();

        xmlWriter.Flush();
        xmlWriter.Close();
      }

      _emrPlugIn.SendMessage(sb.ToString());
    }

    public void AddGuiPatient(System.Xml.XmlWriter xmlWriter)
    {
      //<Patient ID=""PSM-11213"">
      //      <LastName>Smith</LastName>
      //      <FirstName>Peter</FirstName>
      //</Patient>
      xmlWriter.WriteStartElement("Patient");
      if (!String.IsNullOrEmpty(textBoxPatientID.Text))
      {
        xmlWriter.WriteAttributeString("ID", textBoxPatientID.Text);
      }
      if (!String.IsNullOrEmpty(textBoxLastname.Text))
      {
        xmlWriter.WriteElementString("LastName", textBoxLastname.Text);
      }
      if (!String.IsNullOrEmpty(textBoxLastname.Text))
      {
        xmlWriter.WriteElementString("FirstName", textBoxFirstName.Text);
      }

      xmlWriter.WriteStartElement("PatientDataAtPresent");
      if (!String.IsNullOrEmpty(dateTimePicker1.Text))
      {
        xmlWriter.WriteElementString("DateOfBirth", dateTimePicker1.Value.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
      }
      if (!String.IsNullOrEmpty(comboBoxGender.Text))
      {
        xmlWriter.WriteElementString("Gender", comboBoxGender.Text);
      }
      if (!String.IsNullOrEmpty(maskedTextBoxHeight.Text))
      {
        xmlWriter.WriteElementString("Height", Double.Parse(maskedTextBoxHeight.Text).ToString(CultureInfo.InvariantCulture));
      }
      if (!String.IsNullOrEmpty(numericUpDownWeight.Text))
      {
        xmlWriter.WriteElementString("Weight", numericUpDownWeight.Text);
      }
      if (!String.IsNullOrEmpty(comboBoxEthnicity.Text))
      {
        xmlWriter.WriteElementString("Ethnicity", comboBoxEthnicity.Text);
      }
      xmlWriter.WriteEndElement();//PatientDataAtPresent

      xmlWriter.WriteEndElement();//Patient
    }

    private void buttonAddWorklist_Click(object sender, EventArgs e)
    {
      StringBuilder sb = new System.Text.StringBuilder();

      using (System.Xml.XmlTextWriter xmlWriter = new System.Xml.XmlTextWriter(new System.IO.StringWriter(sb, CultureInfo.InvariantCulture)))
      {
        xmlWriter.WriteStartDocument();
        xmlWriter.WriteStartElement("ndd");
        AddCommand(Commands.AddToWorklist.Command, xmlWriter, Commands.AddToWorklist.OrderID, textBoxOrderID.Text);

        xmlWriter.WriteStartElement("Patients");
        AddGuiPatient(xmlWriter);
        xmlWriter.WriteEndElement();//Patients
        xmlWriter.WriteEndElement();
        xmlWriter.WriteEndDocument();

        xmlWriter.Flush();
        xmlWriter.Close();
      }

      _emrPlugIn.SendMessage(sb.ToString());
    }

    private static void AddCommand(string strCommand, System.Xml.XmlTextWriter xmlWriter)
    {
      xmlWriter.WriteStartElement("Command");
      xmlWriter.WriteAttributeString("Type", strCommand);
      xmlWriter.WriteEndElement();//command
    }

    private static void AddCommand(string strCommand, System.Xml.XmlTextWriter xmlWriter, string strParamName, string strParamValue)
    {
      xmlWriter.WriteStartElement("Command");
      xmlWriter.WriteAttributeString("Type", strCommand);

      xmlWriter.WriteStartElement("Parameter");
      xmlWriter.WriteAttributeString("Name", strParamName);
      xmlWriter.WriteValue(strParamValue);
      xmlWriter.WriteEndElement();//Param
      
      xmlWriter.WriteEndElement();//command
    }

    private void buttonPerformTest_Click(object sender, EventArgs e)
    {
      StringBuilder sb = new System.Text.StringBuilder();

      using (System.Xml.XmlTextWriter xmlWriter = new System.Xml.XmlTextWriter(new System.IO.StringWriter(sb, CultureInfo.InvariantCulture)))
      {
        xmlWriter.WriteStartDocument();
        xmlWriter.WriteStartElement("ndd");
        AddCommand(Commands.PerformTest.Command, xmlWriter, Commands.PerformTest.OrderID, textBoxOrderID.Text);

        xmlWriter.WriteStartElement("Patients");
        AddGuiPatient(xmlWriter);
        xmlWriter.WriteEndElement();//Patients
        xmlWriter.WriteEndElement();
        xmlWriter.WriteEndDocument();

        xmlWriter.Flush();
        xmlWriter.Close();
      }

      _emrPlugIn.SendMessage(sb.ToString());
    }

    private void buttonPerformTestType_Click(object sender, EventArgs e)
    {
      StringBuilder sb = new System.Text.StringBuilder();

      using (System.Xml.XmlTextWriter xmlWriter = new System.Xml.XmlTextWriter(new System.IO.StringWriter(sb, CultureInfo.InvariantCulture)))
      {
        xmlWriter.WriteStartDocument();
        xmlWriter.WriteStartElement("ndd");
        AddCommand(Commands.PerformTest.Command, xmlWriter, Commands.PerformTest.TestType, comboBoxTestType.Text);

        xmlWriter.WriteStartElement("Patients");
        AddGuiPatient(xmlWriter);
        xmlWriter.WriteEndElement();//Patients
        xmlWriter.WriteEndElement();
        xmlWriter.WriteEndDocument();

        xmlWriter.Flush();
        xmlWriter.Close();
      }

      _emrPlugIn.SendMessage(sb.ToString());
    }

    private void buttonShowTest_Click(object sender, EventArgs e)
    {
      StringBuilder sb = new System.Text.StringBuilder();

      using (System.Xml.XmlTextWriter xmlWriter = new System.Xml.XmlTextWriter(new System.IO.StringWriter(sb, CultureInfo.InvariantCulture)))
      {
        xmlWriter.WriteStartDocument();
        xmlWriter.WriteStartElement("ndd");
        AddCommand(Commands.ShowTest.Command, xmlWriter, Commands.ShowTest.OrderID, textBoxOrderID.Text);

        xmlWriter.WriteStartElement("Patients");
        AddGuiPatient(xmlWriter);
        xmlWriter.WriteEndElement();//Patients
        xmlWriter.WriteEndElement();
        xmlWriter.WriteEndDocument();

        xmlWriter.Flush();
        xmlWriter.Close();
      }

      _emrPlugIn.SendMessage(sb.ToString());
    }

    private void tabPageSettings_Enter(object sender, EventArgs e)
    {
      checkBoxIncludeCurveData.Checked = this._emrPlugIn.IncludeCurveData;
      checkBoxIncludeTrialValues.Checked = this._emrPlugIn.IncludeTrialValues;
      checkBoxCloseAfterTest.Checked = _emrPlugIn.CloseAfterTest;
      textBoxEchangeFolder.Text = _emrPlugIn.XmlExchangeFile;
    }

 
 

  }
}